const quiz = [
    {
        q:"What is your interest ? ",
        options: ["engineering", "science", "both"],
        answer:0
    },
    {
        q: "What’s your highest level of education? ",
        options:["High school diploma", "Bachelor's degree", "Master's degree", "Doctorate degree", "Professional degree" ],
        answer: 0

    },
    {
        q: "How much time you want to spend on topic? ",
        options:["4/Per week", "8/Per week", "8+/Per week" ],
        answer:0

    }
]